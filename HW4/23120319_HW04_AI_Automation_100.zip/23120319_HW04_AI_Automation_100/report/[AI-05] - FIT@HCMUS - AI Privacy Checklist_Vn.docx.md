**Khoa Công nghệ Thông tin (FIT) – Trường Đại học Khoa học Tự nhiên (HCMUS)**

**CS423 / CSC13003 – Kiểm chứng Phần mềm (AI-augmented · 2026)**

**CHÍNH SÁCH AI · BIỂU MẪU — 2026 v1.0**

# **Bảng Kiểm Quyền Riêng tư & Sử dụng AI Có Trách nhiệm**

*Thực hiện bảng kiểm này TRƯỚC KHI nộp bất kỳ bài tập có dùng AI.*

*Tài liệu được biên soạn lại từ Med Kharbach, PhD (2026) — Mẫu Chính sách Sử dụng AI cho Giáo dục Đại học. Giấy phép CC BY-NC-SA 4.0. Phiên bản này được FIT@HCMUS điều chỉnh cho môn CS423 / CSC13003 Kiểm chứng Phần mềm.*

## **1. Trước khi dùng AI**

[x] Đã xác nhận Cấp độ AI cho bài tập này (Cấp 4).

[x] Dùng tài khoản Antigravity / Claude Code tự chọn (không lưu trữ dữ liệu cá nhân nhạy cảm).

[x] Đã đọc Thoả thuận AI của môn học.

[x] Hiểu rõ artifact nào KHÔNG được sinh bằng AI (Video test thực tế, ảnh chụp bằng chứng có watermark email sinh viên, lịch sử git commit thật).

## **2. Trong khi dùng AI**

[x] Không nhập dữ liệu cá nhân của bạn, khách hàng, bệnh nhân (Dữ liệu tài khoản kiểm thử chỉ sử dụng tài khoản mẫu test@eshop.com, admin@eshop.com).

[x] Không paste nguyên si tài liệu có bản quyền lên AI.

[x] Không paste code công ty / code open-source giới hạn license.

[x] Đã ghi mọi prompt + phản hồi AI vào AI Audit Report (Appendix A) có timestamp.

## **3. Trước khi nộp bài**

[x] Mọi artifact AI sinh đã được gắn tag trong AI Audit Report (8 artifacts A01–A08).

[x] Mọi trích dẫn AI đã được xác minh (nguồn thực sự tồn tại).

[x] Mọi code AI sinh đã được thực thi và test (validate_automation.mjs, export_run_summary.mjs, authorship-reporter.ts, các file spec.ts).

[x] AI Critique 200–300 chữ đã có trong báo cáo (Phụ lục B - 270 từ).

[x] Đoạn Mandatory Disclosure ở cuối báo cáo.

[x] Đính kèm AI Use Disclosure Form (AI-03).

[x] Sẵn sàng cho vấn đáp ngẫu nhiên 5–7 phút tuần kế nộp bài.

## **4. Cam đoan Cuối cùng**

*Trách nhiệm cuối cùng về độ chính xác, tính nguyên bản, và liêm chính của bài nộp này thuộc về tôi. Mọi việc dùng AI không khai báo đều bị coi là vi phạm liêm chính học thuật.*

## **Chữ ký**

| Họ tên sinh viên (in hoa): | TRƯƠNG THÀNH PHÁT |
| :---- | :---- |
| **MSSV:** | 23120319 |
| **Lớp / Khoá:** | Kiểm thử phần mềm - CQ2023/3 - Khóa 2023 |
| **Môn học:** | CS423 / CSC13003 – Kiểm thử phần mềm |
| **Giảng viên:** | Giảng viên: Trần Duy Hoàng<br>Giảng viên: Trương Phước Lộc<br>Giảng viên: Hồ Tuấn Thanh<br>Giảng viên: Lâm Quang Vũ |
| **Ngày:** | 15/11/2026 |
| **Chữ ký:** | Trương Thành Phát |

## **Tham khảo**

* Kharbach, M. (2026). AI Use Policy Templates for Higher Education. CC BY-NC-SA 4.0.  
* ISTQB Foundation Level Syllabus (latest version).  
* Hardman, P. (2025). A Post-AI Learning Taxonomy.  
* Fuster Rabella, M. (2025). OECD Education Working Paper No. 338.  
* Perkins, M., Roe, J., & Furze, L. (2025). AI Assessment Scale.  
* Anthropic (2025). Building reliable AI test agents — engineering blog.  
* DeepEval & Promptfoo documentation — testing frameworks for LLM systems.

