# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fr08-checkout.spec.ts >> FR-08: Cart & Checkout Automation [Run by: 23120319] >> TC-FR08-11: Kiểm tra tính toàn vẹn: Giỏ hàng phải được xóa sạch sau khi thanh toán thành công
- Location: tests\fr08-checkout.spec.ts:30:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('Giỏ hàng của bạn đang trống')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByText('Giỏ hàng của bạn đang trống') with timeout 5000ms
  - waiting for getByText('Giỏ hàng của bạn đang trống')

```

```yaml
- banner:
  - link "EShop":
    - /url: /
  - navigation:
    - link "Giỏ hàng":
      - /url: /cart
    - link "Chào, Test User":
      - /url: /profile
    - button "Thoát"
- main:
  - heading "Giỏ Hàng" [level=2]
  - table:
    - rowgroup:
      - row "Sản phẩm Giá Số lượng Thành tiền Thao tác":
        - columnheader "Sản phẩm"
        - columnheader "Giá"
        - columnheader "Số lượng"
        - columnheader "Thành tiền"
        - columnheader "Thao tác"
    - rowgroup:
      - row "Tai nghe AirPods Pro 2 6,000,000 ₫ 1 6,000,000 ₫ Xóa":
        - cell "Tai nghe AirPods Pro 2"
        - cell "6,000,000 ₫"
        - cell "1"
        - cell "6,000,000 ₫"
        - cell "Xóa":
          - button "Xóa"
  - text: "Tổng tạm tính: 6,000,000 ₫"
  - link "← Mua tiếp":
    - /url: /
  - button "Tiến hành thanh toán"
- contentinfo: © 2026 EShop SUT. Dành cho mục đích kiểm thử.
```

# Test source

```ts
  61  |         if (await productCard.count() > 0) {
  62  |           await productCard.first().getByRole('button', { name: 'Thêm vào giỏ' }).click();
  63  |         } else {
  64  |           await page.getByRole('button', { name: 'Thêm vào giỏ' }).first().click();
  65  |         }
  66  |       }
  67  | 
  68  |       // Step 4: Client-Side Navigation to Cart page
  69  |       await page.getByRole('link', { name: 'Giỏ hàng' }).click();
  70  |       // Assertion 1: Verify URL after client-side navigation
  71  |       await expect(page).toHaveURL(/\/cart/);
  72  | 
  73  |       // Handle Cart Page Specific Test Scenarios
  74  |       if (tc.id === 'TC-FR08-07' || tc.id === 'TC-FR08-08' || tc.id === 'TC-FR08-09') {
  75  |         if (tc.id === 'TC-FR08-07') {
  76  |           // Assertion 2 & 3: Empty cart notification and return shopping link
  77  |           await expect(page.getByText(tc.expected.emptyCartMessage)).toBeVisible();
  78  |           if (tc.expected.hasContinueLink) {
  79  |             await expect(page.getByRole('link', { name: 'Tiếp tục mua sắm' })).toBeVisible();
  80  |           }
  81  |         }
  82  | 
  83  |         if (tc.id === 'TC-FR08-08') {
  84  |           // Unauthenticated checkout guard check
  85  |           page.once('dialog', async (dialog) => {
  86  |             expect(dialog.message()).toContain(tc.expected.alertMessage);
  87  |             await dialog.accept();
  88  |           });
  89  |           await page.getByRole('button', { name: 'Tiến hành thanh toán' }).click();
  90  |           await expect(page).toHaveURL(/\/login/);
  91  |         }
  92  | 
  93  |         if (tc.id === 'TC-FR08-09') {
  94  |           // Remove item from cart FIRST, then verify empty notification
  95  |           await page.getByRole('button', { name: 'Xóa' }).first().click();
  96  |           await expect(page.getByText(tc.expected.emptyCartMessage)).toBeVisible();
  97  |         }
  98  |       } else {
  99  |         // Step 5: Proceed to Checkout page via Client-Side Navigation (Memory Preserved)
  100 |         await page.getByRole('button', { name: 'Tiến hành thanh toán' }).click();
  101 |         await expect(page).toHaveURL(/\/checkout/);
  102 | 
  103 |         // Step 6: Coupon Interaction
  104 |         if (typeof tc.inputs.couponCode === 'string') {
  105 |           const couponInput = page.getByPlaceholder('Nhập mã giảm giá...');
  106 |           await couponInput.fill(tc.inputs.couponCode);
  107 |           // Assertion 4: Input value verification
  108 |           await expect(couponInput).toHaveValue(tc.inputs.couponCode);
  109 | 
  110 |           const applyBtn = page.getByRole('button', { name: 'Áp dụng' });
  111 | 
  112 |           if (tc.expected.buttonDisabled) {
  113 |             // Assertion 5: Disabled button pattern for empty input
  114 |             await expect(applyBtn).toBeDisabled();
  115 |           } else {
  116 |             // Human Review Fix #3: Wait for API response to prevent async race condition
  117 |             const [couponResponse] = await Promise.all([
  118 |               page.waitForResponse(resp => resp.url().includes('/api/apply-coupon')),
  119 |               applyBtn.click(),
  120 |             ]);
  121 | 
  122 |             if (tc.expected.couponSuccess) {
  123 |               await expect(page.getByText('Áp dụng thành công', { exact: false })).toBeVisible();
  124 |               await expect(page.locator('text=Tiết kiệm:')).toBeVisible();
  125 |             } else if (tc.expected.errorMessage) {
  126 |               const errorBanner = page.locator('p.text-red-600');
  127 |               // Assertion 6: Error banner visibility and content check
  128 |               await expect(errorBanner).toBeVisible();
  129 |               await expect(errorBanner).toContainText(tc.expected.errorMessage);
  130 |             }
  131 |           }
  132 |         }
  133 | 
  134 |         // Step 7: Standard Checkout Execution (TC-FR08-01)
  135 |         if (tc.expected.success) {
  136 |           const [checkoutRes] = await Promise.all([
  137 |             page.waitForResponse(resp => resp.url().includes('/api/checkout')),
  138 |             page.getByRole('button', { name: 'Xác Nhận Thanh Toán' }).click(),
  139 |           ]);
  140 |           expect(checkoutRes.status()).toBe(200);
  141 |           await expect(page.getByText(tc.expected.successMessage)).toBeVisible();
  142 |         }
  143 | 
  144 |         // Step 8: SUT Defect Check: Editable total price vulnerability (BUG-UX-02 / TC-FR08-10)
  145 |         if (tc.id === 'TC-FR08-10') {
  146 |           const totalInput = page.locator('input[type="number"]');
  147 |           // Assertion 7: Readonly attribute check on financial field
  148 |           await expect(totalInput).toHaveAttribute('readonly');
  149 |         }
  150 | 
  151 |         // Step 9: SUT Defect Check: Cart not cleared after successful checkout (BUG-UX-03 / TC-FR08-11)
  152 |         if (tc.id === 'TC-FR08-11') {
  153 |           await Promise.all([
  154 |             page.waitForResponse(resp => resp.url().includes('/api/checkout')),
  155 |             page.getByRole('button', { name: 'Xác Nhận Thanh Toán' }).click(),
  156 |           ]);
  157 |           await expect(page.getByText('Thanh toán thành công!')).toBeVisible();
  158 |           // Client-side navigate back to cart to inspect integrity
  159 |           await page.getByRole('link', { name: 'Giỏ hàng' }).click();
  160 |           await expect(page).toHaveURL(/\/cart/);
> 161 |           await expect(page.getByText('Giỏ hàng của bạn đang trống')).toBeVisible();
      |                                                                       ^ Error: expect(locator).toBeVisible() failed
  162 |         }
  163 | 
  164 |         // Step 10: Navigation Check: Back to home button (TC-FR08-12)
  165 |         if (tc.id === 'TC-FR08-12') {
  166 |           await Promise.all([
  167 |             page.waitForResponse(resp => resp.url().includes('/api/checkout')),
  168 |             page.getByRole('button', { name: 'Xác Nhận Thanh Toán' }).click(),
  169 |           ]);
  170 |           await expect(page.getByText('Thanh toán thành công!')).toBeVisible();
  171 |           await page.getByRole('button', { name: 'Quay lại trang chủ' }).click();
  172 |           await expect(page).toHaveURL('/');
  173 |         }
  174 |       }
  175 |     });
  176 |   }
  177 | });
  178 | 
```