# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fr01-registration.spec.ts >> FR-01: Account Registration - Web UI Automation [Run by: 23120319] >> TC-FR01-12: Đăng ký thất bại khi email đã tồn tại trong hệ thống (Duplicate Email)
- Location: tests\fr01-registration.spec.ts:18:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('div[class*="text-red-"], div[role="alert"]').first()
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('div[class*="text-red-"], div[role="alert"]').first() with timeout 5000ms
  - waiting for locator('div[class*="text-red-"], div[role="alert"]').first()

```

```yaml
- banner:
  - link "EShop":
    - /url: /
  - navigation:
    - link "Giỏ hàng":
      - /url: /cart
    - link "Đăng nhập":
      - /url: /login
    - link "Đăng ký":
      - /url: /register
- main:
  - heading "Đăng Ký" [level=2]
  - text: Username
  - textbox
  - text: Mật khẩu
  - textbox
  - link "Quên mật khẩu?":
    - /url: /forgot-password
  - button "Sign In"
  - text: Chưa có tài khoản?
  - link "Đăng ký ngay":
    - /url: /register
- contentinfo: © 2026 EShop SUT. Dành cho mục đích kiểm thử.
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import fs from 'fs';
  3  | import path from 'path';
  4  | 
  5  | // Load external data-driven test cases (FR-01: Account Registration)
  6  | const dataFilePath = path.resolve(__dirname, '../data/fr01-registration.json');
  7  | const testCases = JSON.parse(fs.readFileSync(dataFilePath, 'utf-8'));
  8  | 
  9  | test.describe('FR-01: Account Registration - Web UI Automation [Run by: 23120319]', () => {
  10 |   test.beforeEach(async ({ page, context }) => {
  11 |     // Isolate browser context and clear storage before each test
  12 |     await context.clearCookies();
  13 |     await page.goto('/register');
  14 |     await page.evaluate(() => localStorage.clear());
  15 |   });
  16 | 
  17 |   for (const tc of testCases) {
  18 |     test(`${tc.id}: ${tc.description}`, async ({ page }) => {
  19 |       // Generate unique email to prevent collision across test runs
  20 |       const uniqueSuffix = Date.now() + '_' + Math.floor(Math.random() * 1000);
  21 |       const emailValue = tc.inputs.email.replace('{{uniq}}', uniqueSuffix);
  22 | 
  23 |       // Fill form fields using label-scoped input locators
  24 |       // (Handles SUT unassociated labels where <label> and <input> lack htmlFor/id linkage)
  25 |       if (tc.inputs.name) {
  26 |         await page.locator('label:has-text("Họ Tên") + input').fill(tc.inputs.name);
  27 |       }
  28 |       if (tc.inputs.email) {
  29 |         await page.locator('label:has-text("Email") + input').fill(emailValue);
  30 |       }
  31 |       if (tc.inputs.password) {
  32 |         await page.locator('label:has-text("Mật khẩu") + input').fill(tc.inputs.password);
  33 |       }
  34 | 
  35 |       // Click submit button using accessible role
  36 |       await page.getByRole('button', { name: 'Đăng Ký' }).click();
  37 | 
  38 |       // Multi-assertion patterns based on expected outcome
  39 |       if (tc.expected.success) {
  40 |         // Assertion 1: URL redirection to login page
  41 |         await expect(page).toHaveURL(/\/login/);
  42 |         // Assertion 2: Verify login form is fully rendered and actionable
  43 |         await expect(page.getByRole('button', { name: 'Sign In' })).toBeVisible();
  44 |       } else if (tc.expected.errorText) {
  45 |         // Assertion 3 & 4: Error message banner visibility and exact content match
  46 |         const errorAlert = page.locator('div[class*="text-red-"], div[role="alert"]').first();
> 47 |         await expect(errorAlert).toBeVisible();
     |                                  ^ Error: expect(locator).toBeVisible() failed
  48 |         await expect(errorAlert).toContainText(tc.expected.errorText);
  49 |       } else if (tc.expected.validationField) {
  50 |         // Assertion 5, 6 & 7: Native HTML5 validation flag, non-empty message, and URL integrity
  51 |         const fieldLabelMap: Record<string, string> = {
  52 |           name: 'Họ Tên',
  53 |           email: 'Email',
  54 |           password: 'Mật khẩu',
  55 |         };
  56 |         const targetInput = page.locator(`label:has-text("${fieldLabelMap[tc.expected.validationField]}") + input`);
  57 |         
  58 |         const isInvalid = await targetInput.evaluate((el: HTMLInputElement) => !el.checkValidity());
  59 |         expect(isInvalid).toBe(true);
  60 | 
  61 |         const valMsg = await targetInput.evaluate((el: HTMLInputElement) => el.validationMessage);
  62 |         expect(valMsg.length).toBeGreaterThan(0);
  63 | 
  64 |         await expect(page).toHaveURL(/\/register/);
  65 |       }
  66 |     });
  67 |   }
  68 | });
  69 | 
```