# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: fr12-access-control.spec.ts >> FR-12: Access Control - Admin Web Automation [Run by: 23120319] >> TC-FR12-12: Kiểm tra lỗ hổng Broken Access Control: Backend không được phép trả dữ liệu người dùng cho vai trò user
- Location: tests\fr12-access-control.spec.ts:38:5

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: 403
Received: 200
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - heading "EShop Admin" [level=1] [ref=e5]
    - list [ref=e6]:
      - listitem [ref=e7] [cursor=pointer]: Dashboard
      - listitem [ref=e8] [cursor=pointer]: Danh mục
      - listitem [ref=e9] [cursor=pointer]: Sản phẩm
      - listitem [ref=e10] [cursor=pointer]: Mã Giảm Giá
      - listitem [ref=e11] [cursor=pointer]: Đơn hàng
      - listitem [ref=e12] [cursor=pointer]: Người dùng
      - listitem [ref=e13] [cursor=pointer]: Đăng xuất
  - generic [ref=e15]:
    - heading "Dashboard" [level=2] [ref=e16]
    - generic [ref=e17]:
      - generic [ref=e18]:
        - heading "Tổng doanh thu (Delivered)" [level=3] [ref=e19]
        - paragraph [ref=e20]: 0 ₫
      - generic [ref=e21]:
        - heading "Tổng số đơn hàng" [level=3] [ref=e22]
        - paragraph [ref=e23]: "6"
```

# Test source

```ts
  57  |         });
  58  |       }
  59  | 
  60  |       // Step 2: Open Admin Web Application (Port 5174)
  61  |       await page.goto(tc.setup.adminUrl);
  62  |       // Assertion 1: Verify URL targets Admin Web
  63  |       await expect(page).toHaveURL(/5174/);
  64  | 
  65  |       // Step 3: Handle UI Login Scenarios
  66  |       if (tc.inputs.email !== null && tc.inputs.password !== null) {
  67  |         const loginHeading = page.locator('h2:has-text("Admin Login")');
  68  |         // Assertion 2: Verify login heading visibility
  69  |         await expect(loginHeading).toBeVisible();
  70  | 
  71  |         const emailInput = page.getByPlaceholder('Email');
  72  |         const passInput = page.getByPlaceholder('Password');
  73  | 
  74  |         // Assertion 3: Verify password input attribute
  75  |         await expect(passInput).toHaveAttribute('type', 'password');
  76  | 
  77  |         await emailInput.fill(tc.inputs.email);
  78  |         // Assertion 4: Verify email value entered
  79  |         await expect(emailInput).toHaveValue(tc.inputs.email);
  80  | 
  81  |         await passInput.fill(tc.inputs.password);
  82  | 
  83  |         if (tc.expected.alertMessage) {
  84  |           // Listen for browser dialog alert
  85  |           page.once('dialog', async (dialog) => {
  86  |             expect(dialog.message()).toContain(tc.expected.alertMessage);
  87  |             await dialog.accept();
  88  |           });
  89  |         }
  90  | 
  91  |         const loginBtn = page.getByRole('button', { name: 'Login' });
  92  |         await loginBtn.click();
  93  | 
  94  |         if (tc.expected.success) {
  95  |           const adminTitle = page.locator('h1:has-text("EShop Admin")');
  96  |           await expect(adminTitle).toBeVisible();
  97  |           const revenueText = page.locator('text=Tổng doanh thu');
  98  |           // Assertion 5: Text content assertion
  99  |           await expect(revenueText).toContainText('Tổng doanh thu');
  100 |         } else if (tc.expected.stayOnLogin) {
  101 |           await expect(loginHeading).toBeVisible();
  102 |         }
  103 |       }
  104 | 
  105 |       // Step 4: Handle Unauthenticated access verification (TC-FR12-05)
  106 |       if (tc.expected.loginFormVisible && tc.setup.injectToken === 'none' && !tc.inputs.clickLogout) {
  107 |         const loginHeader = page.locator('h2:has-text("Admin Login")');
  108 |         await expect(loginHeader).toBeVisible();
  109 |       }
  110 | 
  111 |       // Step 5: Handle Admin Navigation Tabs (TC-FR12-07 .. TC-FR12-10)
  112 |       if (tc.inputs.clickTab) {
  113 |         await page.getByText(tc.inputs.clickTab, { exact: true }).click();
  114 |         const tabTitleHeader = page.locator(`h2:has-text("${tc.expected.tabTitle}")`);
  115 |         await expect(tabTitleHeader).toBeVisible();
  116 | 
  117 |         if (tc.expected.hasNewCategoryInput) {
  118 |           const categoryInput = page.getByPlaceholder('Tên danh mục mới');
  119 |           await expect(categoryInput).toBeVisible();
  120 |         }
  121 |         if (tc.expected.hasCsvImportSection) {
  122 |           const csvText = page.locator('text=Import sản phẩm từ CSV');
  123 |           await expect(csvText).toBeVisible();
  124 |         }
  125 |         if (tc.expected.hasCouponForm) {
  126 |           const couponInput = page.getByPlaceholder('Mã coupon (VD: SAVE10)');
  127 |           await expect(couponInput).toBeVisible();
  128 |         }
  129 |         if (tc.expected.hasOrderTable) {
  130 |           const orderTable = page.locator('table');
  131 |           await expect(orderTable).toBeVisible();
  132 |         }
  133 |       }
  134 | 
  135 |       // Step 6: Handle Admin Logout (TC-FR12-06)
  136 |       if (tc.inputs.clickLogout) {
  137 |         await page.getByText('Đăng xuất').click();
  138 |         const loginHeader = page.locator('h2:has-text("Admin Login")');
  139 |         await expect(loginHeader).toBeVisible();
  140 |         const storedToken = await page.evaluate(() => localStorage.getItem('adminToken'));
  141 |         expect(storedToken).toBeNull();
  142 |       }
  143 | 
  144 |       // Step 7: Handle Invalid Token Defense (TC-FR12-11)
  145 |       if (tc.id === 'TC-FR12-11') {
  146 |         const loginHeader = page.locator('h2:has-text("Admin Login")');
  147 |         await expect(loginHeader).toBeVisible();
  148 |       }
  149 | 
  150 |       // Step 8: Handle Broken Access Control Security Check (TC-FR12-12 / SUT Defect)
  151 |       if (tc.id === 'TC-FR12-12') {
  152 |         // A regular user token must be forbidden (HTTP 403) from accessing admin user list
  153 |         const res = await page.request.get('http://localhost:3000/api/admin/users', {
  154 |           headers: { Authorization: `Bearer ${userToken}` },
  155 |         });
  156 |         // SUT Defect Check: Backend incorrectly returns 200 instead of 403
> 157 |         expect(res.status()).toBe(tc.expected.expectedStatus);
      |                              ^ Error: expect(received).toBe(expected) // Object.is equality
  158 |       }
  159 |     });
  160 |   }
  161 | });
  162 | 
```